package Assigned;
class Far {
int x=5;
void display()
{
	System.out.println("Hi far class");
}
public static class In1{  
void hello()
{
	System.out.println("Hi static inner class");
}   
}
class In{  
	int y=10;
void hello()
{
	System.out.println("Hi inner class");
}    
}
}
public class Inner_class{
		public static void main(String[] args) {
			Far obj=new Far();
			System.out.println(obj.x); 
			obj.display();
			Far.In1 obj2=new Far.In1();
			obj2.hello();
			
			Far.In obj1=obj.new In();
			System.out.println(obj1.y);
			obj1.hello();
					
		}
	}

