package Assigned;
public class Strings {
public static void main(String[] args) {			
//String
String a=new String("Mathivathani");
//Length of the string  
System.out.println("Length of the string"+" "+a.length());
//Compare
String b="Arunsankar";
String c="Arun";
System.out.println("Comparision"+" "+b.compareTo(c));
//replace
String d="Wonder";
System.out.println("Replacing 'o' in wonder with 'a'"+" "+d.replace('o', 'a'));
//upper case
System.out.println("String in capital letters" + " "+a.toUpperCase());
//lower case
System.out.println("String in small letters" + " "+a.toLowerCase());
//equals
String f="Seven wonders of the world";
String g="Seven wonders of the WORLD";
System.out.println("Checking whether both the strings are equal:"+" "+g.equals(f));
//empty
String h="Friend";
System.out.println("Checking whether the string is empty:"+h.isEmpty());
String h1="";
System.out.println("Checking whether the string is empty:"+h1.isEmpty());
System.out.println("\n");
//Creating StringBuffer 
System.out.println("STRING BUFFER");
StringBuffer buffer=new StringBuffer("Hari studies sixth standard.");
//append method
System.out.println(buffer);
buffer=buffer.append("Hari is a nice boy.");
System.out.println("After appending:"+" "+buffer);
//Character at some index
System.out.println("Character at index 3 is" + " "+buffer.charAt(3));
//length of the buffer
System.out.println("Length of the buffer"+buffer.length());
//insert 
buffer.insert(4,"haran");
System.out.println("After insertion"+buffer);
//replace method
System.out.println("After replacement:"+buffer.replace(0,4,"HARI"));
//reverse of the buffer
  System.out.println("After deletion:"+buffer.reverse());
//delete method
 System.out.println("After deletion of first character:"+buffer.deleteCharAt(0));
//StringBuilder
System.out.println("\n");
System.out.println("STRING BUILDER");
StringBuilder build=new StringBuilder("Everything is possible  ");
System.out.println(build);
build.append("if there is hardwork.");
System.out.println("After appending:"+build);
System.out.println("After deleting spaces:"+build.delete(24,25));
System.out.println(build.insert(14,"never"));
System.out.println("Comparing whether it is equal to other string"+build.equals(buffer));
System.out.println("After reversal:"+build.reverse());		
//conversion	
System.out.println("\n");
System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
String x = "Mathi"; 
// conversion from String object to StringBuffer 
StringBuffer v = new StringBuffer(x); 
v.reverse(); 
System.out.println("String to StringBuffer");
System.out.println(x);   
// conversion from String object to StringBuilder 
StringBuilder tr = new StringBuilder(); 
tr.append("Vathani"); 
System.out.println("String to StringBuilder");
System.out.println(tr);              		
		}
}