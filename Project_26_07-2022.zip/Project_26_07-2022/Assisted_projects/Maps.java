package Assigned;
import java.util.*;
import java.util.HashMap;
public class Maps {
	public static void main(String[] args)
{
//Hash map 
System.out.println("HASH MAP");
HashMap<String, Integer> map1 = new HashMap<String,Integer>();
map1.put("Ajith", 10);
map1.put("Vijay", 20);
map1.put("Surya", 30);
map1.put("Dhanush",40);
map1.put("Jai", 50);
System.out.println("Size of map: "+ map1.size());
System.out.println(map1);
// Checking if a key is present 
if (map1.containsKey("Surya")) {
Integer a = map1.get("Surya");
// Printing value for the corresponding key
System.out.println("value for key is" +" "+a);
//removing an element from the hash map
map1.remove("Jai",50);
System.out.println(map1);
System.out.println("\n");
			}
//Tree map
// Creating the Tree map 
System.out.println("TREE MAP");
TreeMap<Integer, String> cars= new TreeMap<Integer, String>();
cars.put(50, "Tavera");
cars.put(15, "Rolls_Royce");
cars.put(69, "Hyundai");
cars.put(12, "Taxi");
cars.put(16, "Audi");
// Elements of Tree map
System.out.println("Treemap" + cars);
System.out.println("Key values in treemap"+cars.keySet());
System.out.println("\n");
//Hash table
System.out.println("HASH TABLE");
//Creating a hash table
Hashtable<Integer, String> s = new Hashtable<Integer,String>();
s.put(1, "one");
s.put(2, "two");
s.put(3, "three");
s.put(4, "four");
// Print the values
System.out.println("The mappings are" + s);
}
}



