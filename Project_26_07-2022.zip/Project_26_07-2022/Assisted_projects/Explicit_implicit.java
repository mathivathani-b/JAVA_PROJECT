package Assigned;
public class Explicit_implicit {
    static void impli()
	{
/*Implicit type casting(integer to long to double)*/
		int j=88;
		long k=j;
		double l=j;
		System.out.println("IMPLICIT CONVERSION");
		System.out.println("Integer value"            +" "+ j);
		System.out.println("Long value of integer"    +" "+ k);
		System.out.println("Double value of integer"  +" "+ l);
	}
	static void expli()
	{
/* Explicit type casting(double to long to integer)*/
		double j = 88.00056;
		long k = (long)j;
		int l = (int)j;
		System.out.println("EXPLICIT CONVERSION");
		System.out.println("Double value         " +" "+ j);
		System.out.println("Long value of double " +" "+ k);
		System.out.println("Int value of double  " +" "+ l);
	}
		public static void main(String[] args)
		{
			impli();
			expli();
		}
	}