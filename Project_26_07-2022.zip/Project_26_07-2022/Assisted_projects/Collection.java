package Assigned;
	import java.util.ArrayList;
	import java.util.LinkedList;
	import java.util.HashSet;
	public class Collection{
	public static void main(String[] args) {
	//Array list
	System.out.println("ArrayList");
	ArrayList<String> flower=new ArrayList<>();   
	flower.add("Lily");
	flower.add("Rose");    	   
	System.out.println(flower);  
	System.out.println("\n");
	//linked list
	System.out.println("Linkedlist");
	LinkedList<String> cars=new LinkedList<String>();  
	cars.add("Alex");  
	cars.add("John"); 
	System.out.println(cars);
	System.out.println("\n");
	 //hash set
	 System.out.println("Hashset");
	 HashSet<Integer> hash=new HashSet<Integer>();  
	 hash.add(1);  
	 hash.add(2);  
	 hash.add(3);
	 System.out.println(hash);

	} 
	}  


