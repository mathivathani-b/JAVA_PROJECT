package Assigned;
import java.util.*;
public class Array {
	static void search(int a[],int x)
	{
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			if(x==a[i])
			{
				System.out.println("The searched thing is present as"+"number"+(i+1)+"in the list");
				break;
			}
			count++;
		}
		if(count==a.length)
			System.out.println("The number is not found");
	}
	public static void main(String[] args) {
		int n,m;
		int[] arr=new int[10];
		Scanner s=new Scanner(System.in);
        System.out.println("Enter the total numbers in the set");
        n=s.nextInt();
		System.out.println("Enter the set of numbers");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		System.out.println("Enter the values to be searched");
		m=s.nextInt();
		System.out.println("The values in the set are");
		for(int i=0;i<n;i++)
		{
		System.out.println(arr[i]);
		 
	}
		search(arr,m);
}
}