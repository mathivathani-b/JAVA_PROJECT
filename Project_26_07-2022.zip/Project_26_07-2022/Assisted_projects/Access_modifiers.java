package Assigned;
class Modifiers{	
/*default access modifier-visible within package */
	void display()
	{
		System.out.println("Default access modifier");
	}
/* public access modifier-visible everywhere*/
	public void display2()
	{
		System.out.println("Public access modifier");
	}
/*protected access modifier- not visible outside the package */
	protected void display3()
	{
		System.out.println("Protected access modifier");
	}
/*private access modifier-not visible outside the class-so getters and setters are used*/ 
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
		
	}

public class Access_modifiers {
		public static void main(String[] args) {
	Modifiers obj=new Modifiers();
	obj.display();
	obj.display2();
	obj.display3();
	obj.setName("Private access modifier");
	System.out.println(obj.getName());
		
	}

}
