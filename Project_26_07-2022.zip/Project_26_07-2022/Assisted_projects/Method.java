package Assigned;
/*ways of calling a method*/
/* method overloading*/
public class Method { 
	static int multi(int x, int y)   
	{  
	return x*y;  
	}  
	static double multi(double x,double y)   
	{  
	return x*y;  
	}    
	//non-static method  
	void displayMessage()   
	{  
	System.out.println("Non-static method is called.");  
	}  
	//calling by value
	int operation(int val) {
		val =val*10/100;
		return(val);
	}
	public static void main(String[] args)   
	{  
	int a = multi(10,2);  
	double b = multi(10.01,1.00); 
	System.out.println("Multiplied integer values: " +a);  
	System.out.println("Multiplied double values: " +b);
	Method m=new Method();    
	m.displayMessage(); 
    System.out.println("Calling by value"+" "+m.operation(10));
	}  
	}  
