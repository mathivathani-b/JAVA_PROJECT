package Assigned;
//Default constructor automatically initialized to zero
class Constr1
{
	int roll_no;
	String name;
	void display() 
	{
	System.out.println(roll_no+" "+name);
	}
}
//Parameterized constructor
class Constr2{
	int bench_no;
	String name;
	Constr2(int p,String l)
		{
		bench_no=p;
		name=l;
		}
		void display() {
		System.out.println(bench_no+" "+name);
		}
	}
public class Constructor {
public static void main(String[] args) {
		Constr1 n1=new Constr1();
		Constr2 s1=new Constr2(1,"Kalai");
		Constr2 s2=new Constr2(2,"Sukirtha");
		Constr2 s3=new Constr2(3,"Mirudula");
		n1.display();
		s1.display();
		s2.display();
		s3.display();
			}
	}


